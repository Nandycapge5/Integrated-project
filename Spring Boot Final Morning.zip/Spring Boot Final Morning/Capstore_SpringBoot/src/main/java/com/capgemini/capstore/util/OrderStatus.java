package com.capgemini.capstore.util;

public enum OrderStatus {
	PLACED, PACKED, SHIPPED, DELIVERED,RETURNED,CANCELLED;
}