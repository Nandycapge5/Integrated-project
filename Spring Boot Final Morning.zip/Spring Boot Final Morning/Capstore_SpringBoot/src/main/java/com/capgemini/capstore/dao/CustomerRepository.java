package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
	List<Customer> findAllByCustomerName(String customerName);

	List<Customer> findAllByCustomerNameIgnoreCase(String keyword);

	@Query("FROM Customer as c where lower(c.customerName) like lower(concat('%', ?1,'%'))")
	List<Customer> getAllCustomerByCustomerName(String customerName);
}
