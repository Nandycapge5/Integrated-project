package com.capgemini.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
@Table(name = "capstore_products")
public class Product {
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDescription="
				+ productDescription + ", productQuantity=" + productQuantity + ", productPrice=" + productPrice
				+ ", productDiscount=" + productDiscount + ", merchant=" + merchant + ", category=" + category
				+ ", stock=" + stock + "]";
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq_gen")
	@SequenceGenerator(name = "product_seq_gen", initialValue = 10000, sequenceName = "product_seq")
	private long productId;
	@Column(length = 50)
	@Size(min=3,max=50)
	private String productName;
	@Column(length = 100)
	@Size(min=3,max=150)
	private String productDescription;
	@Min(0)
	@Max(1000)
	private int productQuantity;
	@Min(message = "Price must not be less than 1",value = 1)
	@Max(message = "Price value is allowed up to 10000",value = 10000)
	private double productPrice;
	@Min(message = "discount must not be less than 1",value = 1)
	@Max(message = "discount value is allowed up to 10000",value = 10000)
	private double productDiscount;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private Merchant merchant;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="t_merchant_id",nullable = true)
	private ThirdPartyMerchant thirdPartyMerchant;
	@ManyToOne(fetch = FetchType.LAZY)
	private Category category;
	@OneToOne
	private Stock stock;

	public Product() {
		super();
	}

	public Product(long productId, String productName, String productDescription, int productQuantity,
			double productPrice, double productDiscount, Merchant merchant,ThirdPartyMerchant thirdPartyMerchant,Category category, Stock stock) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDescription = productDescription;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.merchant = merchant;
		this.thirdPartyMerchant = thirdPartyMerchant;
		this.category = category;
		this.stock = stock;
	}

	public ThirdPartyMerchant getThirdPartyMerchant() {
		return thirdPartyMerchant;
	}

	public void setThirdPartyMerchant(ThirdPartyMerchant thirdPartyMerchant) {
		this.thirdPartyMerchant = thirdPartyMerchant;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public double getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(double productDiscount) {
		this.productDiscount = productDiscount;
	}
}