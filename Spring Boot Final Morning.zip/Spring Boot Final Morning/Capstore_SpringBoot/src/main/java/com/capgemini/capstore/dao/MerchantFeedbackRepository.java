package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.util.MerchantFeedbackStatus;

public interface MerchantFeedbackRepository extends JpaRepository<MerchantFeedback,Long> {

	List<MerchantFeedback> findAllByStatus(MerchantFeedbackStatus status);

}
