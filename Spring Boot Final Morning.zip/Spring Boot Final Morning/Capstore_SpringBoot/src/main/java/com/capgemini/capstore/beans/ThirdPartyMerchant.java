package com.capgemini.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.capgemini.capstore.util.Status;

@Entity
@Table(name = "capstore_t_merchants")
public class ThirdPartyMerchant {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant3_seq_gen")
	@SequenceGenerator(name = "merchant3_seq_gen", initialValue = 10000, sequenceName = "merchant3_seq_gen")
	private long merchantId;
	@Column(length = 20)
	@Size(min = 3,max=20)
	@NotNull
	private String merchantName;
	@Column(length = 10)
	@Size(max = 10, min = 10)
	@NotNull
	private String merchantContactNo;
	private Status merchantStatus;
	/**
	 * @return the merchantId
	 */
	public long getMerchantId() {
		return merchantId;
	}


	/**
	 * @param merchantId
	 *            the merchantId to set
	 */
	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	/**
	 * @return the merchantName
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * @param merchantName
	 *            the merchantName to set
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}



	/**
	 * @return the merchantContactNo
	 */
	public String getMerchantContactNo() {
		return merchantContactNo;
	}

	/**
	 * @param merchantContactNo
	 *            the merchantContactNo to set
	 */
	public void setMerchantContactNo(String merchantContactNo) {
		this.merchantContactNo = merchantContactNo;
	}
	
	public ThirdPartyMerchant() {
		super();
	}

	

	public Status getMerchantStatus() {
		return merchantStatus;
	}

	public void setMerchantStatus(Status merchantStatus) {
		this.merchantStatus = merchantStatus;
	}

	
}
