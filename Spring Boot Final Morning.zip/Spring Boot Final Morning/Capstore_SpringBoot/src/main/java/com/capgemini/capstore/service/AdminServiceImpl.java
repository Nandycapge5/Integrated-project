package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Category;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Stock;
import com.capgemini.capstore.beans.ThirdPartyMerchant;
import com.capgemini.capstore.dao.CategoryRepository;
import com.capgemini.capstore.dao.CouponRepository;
import com.capgemini.capstore.dao.CustomerRepository;
import com.capgemini.capstore.dao.DeliveryStatusRepository;
import com.capgemini.capstore.dao.InvoiceRepository;
import com.capgemini.capstore.dao.MerchantFeedbackRepository;
import com.capgemini.capstore.dao.MerchantRepository;
import com.capgemini.capstore.dao.OrderRepository;
import com.capgemini.capstore.dao.ProductRepository;
import com.capgemini.capstore.dao.StockRepository;
import com.capgemini.capstore.dao.ThirdPartyMerchantRepository;
import com.capgemini.capstore.exception.CapstoreException;
import com.capgemini.capstore.util.MerchantFeedbackStatus;
import com.capgemini.capstore.util.OrderStatus;
import com.capgemini.capstore.util.Status;

@Service("adminService")
public class AdminServiceImpl implements AdminService {

	@Autowired
	MerchantRepository merchantRepo;
	@Autowired
	CouponRepository couponRepo;
	@Autowired
	ProductRepository productRepo;
	@Autowired
	CategoryRepository categoryRepo;
	@Autowired
	StockRepository stockRepo;
	@Autowired
	CustomerRepository customerRepo;
	@Autowired
	DeliveryStatusRepository deliveryStatusRepo;
	@Autowired
	ThirdPartyMerchantRepository thirdPartyMerchantRepo;
	@Autowired
	InvoiceRepository invoiceRepo;
	@Autowired
	MerchantFeedbackRepository merchantFeedbackRepo;
	@Autowired
	OrderRepository orderRepo;

	@SuppressWarnings("unused")
	@Override
	public void authenticateAdmin() throws CapstoreException {
		/*
		 * Authentication conditions to be added later
		 */
		if (false)
			throw new CapstoreException("You are not allowed to access this functionality.");
	}

	/*
	 * Merchant Operations
	 * 
	 */
	@Override
	public Merchant viewMerchant(Long merchantId) throws CapstoreException {
		authenticateAdmin();
		if (!merchantRepo.existsById(merchantId)) {
			throw new CapstoreException("Merchant with ID " + merchantId + " could not be found.");

		}
		return merchantRepo.getOne(merchantId);
	}

	@Override
	public Merchant addMerchant(Merchant merchant) throws CapstoreException {
		authenticateAdmin();
		merchant.setMerchantStatus(Status.ACTIVE);
		merchantRepo.save(merchant);
		return merchant;
	}
	@Override
	public Merchant updateMerchant(Merchant merchant) throws CapstoreException {
		authenticateAdmin();
		Long merchantId = merchant.getMerchantId();
		if (!merchantRepo.existsById(merchantId)) {
			throw new CapstoreException("Merchant with ID " + merchantId + " could not be found.");

		}
		return merchantRepo.save(merchant);
	}
	@Override
	public boolean deleteMerchant(Long merchantId) throws CapstoreException {
		authenticateAdmin();
		if (!merchantRepo.existsById(merchantId)) {
			throw new CapstoreException("Merchant with ID " + merchantId + " could not be found.");
		}
		merchantRepo.deleteById(merchantId);
		return true;
	}

	@Override
	public List<Merchant> viewAllMerchants() throws CapstoreException {
		authenticateAdmin();
		return merchantRepo.findAll();
	}

	/*
	 * Third Party Merchant Operations
	 * 
	 */
	@Override
	public ThirdPartyMerchant viewThirdPartyMerchant(Long merchantId) throws CapstoreException {
		authenticateAdmin();
		if (!thirdPartyMerchantRepo.existsById(merchantId)) {
			throw new CapstoreException("Third Party Merchant with ID " + merchantId + " could not be found.");

		}
		return thirdPartyMerchantRepo.findById(merchantId).get();
	}

	@Override
	public ThirdPartyMerchant addThirdPartyMerchant(ThirdPartyMerchant merchant) throws CapstoreException {
		authenticateAdmin();
		merchant.setMerchantStatus(Status.ACTIVE);
		return thirdPartyMerchantRepo.save(merchant);
	}

	@Override
	public boolean deleteThirdPartyMerchant(Long merchantId) throws CapstoreException {
		authenticateAdmin();
		if (!thirdPartyMerchantRepo.existsById(merchantId)) {
			throw new CapstoreException("Third Party Merchant with ID " + merchantId + " could not be found.");

		}
		thirdPartyMerchantRepo.deleteById(merchantId);
		return true;
	}

	@Override
	public List<ThirdPartyMerchant> viewAllThirdPartyMerchant() throws CapstoreException {
		authenticateAdmin();
		return thirdPartyMerchantRepo.findAll();
	}
	@Override
	public ThirdPartyMerchant updateThirdPartyMerchant(ThirdPartyMerchant merchant) throws CapstoreException {
		authenticateAdmin();
		Long merchantId = merchant.getMerchantId();
		if (!thirdPartyMerchantRepo.existsById(merchantId)) {
			throw new CapstoreException("Merchant with ID " + merchantId + " could not be found.");
		}
		return thirdPartyMerchantRepo.save(merchant);
	}
	/*
	 * Coupon Operations
	 * 
	 */
	@Override
	public Coupon addCoupon(Coupon coupon) throws CapstoreException {
		authenticateAdmin();
		return couponRepo.save(coupon);
	}

	@Override
	public Coupon updateCoupon(Coupon coupon) throws CapstoreException {
		authenticateAdmin();
		if (!couponRepo.existsById(coupon.getCouponId())) {
			throw new CapstoreException("Could not find the coupon with id "+coupon.getCouponId()+".");
		}
		Coupon couponReturned = couponRepo.getOne(coupon.getCouponId());
		return couponRepo.save(couponReturned);

	}

	@Override
	public boolean deleteCoupon(Long couponId) throws CapstoreException {
		authenticateAdmin();
		if (!couponRepo.existsById(couponId)) {
			throw new CapstoreException("Could not find the coupon with id "+couponId+".");
		}
		couponRepo.deleteById(couponId);
		return true;
	}

	@Override
	public List<Coupon> viewAllCoupons() throws CapstoreException {
		authenticateAdmin();
		return couponRepo.findAll();
	}

	/*
	 * Category Operations
	 */
	@Override
	public Category getCategory(Long categoryId) throws CapstoreException {
		authenticateAdmin();
		if (!categoryRepo.existsById(categoryId)) {
			throw new CapstoreException("Could not find the category.");

		}
		return categoryRepo.findById(categoryId).get();
	}

	@Override
	public Category addCategory(Category category) throws CapstoreException {
		authenticateAdmin();
		if (category.getCategoryGender() == null) {
			throw new CapstoreException("Gender cant be null in category");
		}
		if (category.getCategoryType() == null) {
			throw new CapstoreException("Category Name cant be null in category");
		}
		return categoryRepo.save(category);
	}

	@Override
	public List<Category> viewAllCategory() throws CapstoreException {
		authenticateAdmin();
		return categoryRepo.findAll();
	}

	@Override
	public boolean deleteCategory(Long categoryId) throws CapstoreException {
		authenticateAdmin();
		if (!categoryRepo.existsById(categoryId)) {
			throw new CapstoreException("Could not find the category.");
		}
		categoryRepo.deleteById(categoryId);
		return true;
	}

	/*
	 * Product Operations
	 * 
	 */
	@Override
	public Product addProduct(Product product) throws CapstoreException {
		authenticateAdmin();
		Stock stock = new Stock();
		if (product.getStock() == null) {
			product.setStock(stock);
			product.getStock().setTotalQuantity(1);
			product.getStock().setAvailable(1);
		}
		stockRepo.save(stock);
		return productRepo.save(product);
	}

	@Override
	public Product updateStock(Product product) throws CapstoreException {
		authenticateAdmin();
		if (!productRepo.existsById(product.getProductId())) {
			throw new CapstoreException("Product could not be found");
		}
		Product productReturned = productRepo.getOne(product.getProductId());
		Stock stockReturned = productReturned.getStock();
		Stock stock = product.getStock();
		if (stock != null) {
			Integer totalQuantity = stock.getTotalQuantity();
			Integer available = stock.getAvailable();
			if (totalQuantity >= available) {
				if (totalQuantity != null) {
					stockReturned.setTotalQuantity(totalQuantity);
				}
				if (available != null) {
					stockReturned.setAvailable(available);
				}
			}
			else
			{
				throw new CapstoreException("Total Quantity cannot be less than available quantity.");
			}
			stockRepo.save(stockReturned);
		}
		return productRepo.getOne(product.getProductId());
	}

	@Override
	public List<Product> viewAllProducts() throws CapstoreException {
		authenticateAdmin();
		return productRepo.findAll();
	}

	@Override
	public Product viewProduct(Long productId) throws CapstoreException {
		authenticateAdmin();
		if (!productRepo.existsById(productId)) {
			throw new CapstoreException("Could not find the product.");

		}
		return productRepo.findById(productId).get();
	}

	@Override
	public boolean deleteProduct(Long productId) throws CapstoreException {
		authenticateAdmin();
		if (!productRepo.existsById(productId)) {
			throw new CapstoreException("Could not find the product.");
		}
		productRepo.deleteById(productId);
		return true;
	}

	@Override
	public List<Product> findAllProductsByMerchantId(Long merchantId) throws CapstoreException {
		authenticateAdmin();
		Merchant merchant = viewMerchant(merchantId);
		return productRepo.findAllByMerchant(merchant);
	}

	@Override
	public List<Product> findAllProductsByCategoryId(Long categoryId) throws CapstoreException {
		authenticateAdmin();
		Category category = getCategory(categoryId);
		return productRepo.findAllByCategory(category);
	}

	@Override
	public List<Product> findAllProductsByThirdPartyMerchantId(Long merchantId) throws CapstoreException {
		authenticateAdmin();
		ThirdPartyMerchant merchant = viewThirdPartyMerchant(merchantId);
		return productRepo.findAllByThirdPartyMerchant(merchant);
	}

	/*
	 * Admin Search Operation
	 */

	@Override
	public List<Product> getAllProductByProductName(String productName) throws CapstoreException {
		authenticateAdmin();
		return productRepo.getAllProductByProductName(productName);
	}

	@Override
	public List<Customer> getAllCustomerByCustomerName(String customerName) throws CapstoreException {
		authenticateAdmin();
		return customerRepo.getAllCustomerByCustomerName(customerName);
	}

	@Override
	public List<Merchant> getAllMerchantByMerchantName(String merchantName) throws CapstoreException {
		authenticateAdmin();
		return merchantRepo.getAllMerchantByMerchantName(merchantName);
	}

	/*
	 * Delivery Status
	 */
	@Override
	public List<DeliveryStatus> getDeliveryStatus(String statusString) throws CapstoreException {
		authenticateAdmin();
		OrderStatus status;
		try {
			status = OrderStatus.valueOf(statusString.toUpperCase());
		} catch (IllegalArgumentException e) {
			throw new CapstoreException("Not a valid delivery status");
		}
		return deliveryStatusRepo.findAllByStatus(status);
	}

	
	@Override
	public DeliveryStatus updateDeliveryStatus(Long deliveryStatusId, String statusString) throws CapstoreException {
		authenticateAdmin();
		OrderStatus status;
		try {
			status = OrderStatus.valueOf(statusString.toUpperCase());
		} catch (IllegalArgumentException e) {
			throw new CapstoreException("Not a valid delivery status");
		}
		if (!deliveryStatusRepo.existsById(deliveryStatusId)) {
			throw new CapstoreException("No status found");
		}
		DeliveryStatus deliveryStatusReturned = deliveryStatusRepo.getOne(deliveryStatusId);
		if (deliveryStatusReturned.getStatus() == status) {
			throw new CapstoreException("Could not change the status");
		}
		deliveryStatusReturned.setStatus(status);
		return deliveryStatusRepo.save(deliveryStatusReturned);
	}
	
	@Override
	public DeliveryStatus addDeliveryStatus(DeliveryStatus deliveryStatus) {
		return deliveryStatusRepo.save(deliveryStatus);
	}
	/*
	 * Cart Management
	 */

	@Override
	public String changeCartMinimumValue(double value) throws CapstoreException {
		authenticateAdmin();
		if (value <= 0) {
			throw new CapstoreException("Invalid minimum cart value");
		}
		Cart.minimumValue = value;
		return "Minimum cart value changed successfully.";
	}
	@Override
	public Double getCartMinimumValue() {
		return Cart.minimumValue;
	}
/*
 * Merchant Feedback
 */
	@Override
	public MerchantFeedback addMerchantFeedback(MerchantFeedback merchantFeedback)  {//for adding dummy data
		return merchantFeedbackRepo.save(merchantFeedback);
	}
	@Override
	public MerchantFeedback changeFeedbackStatus(MerchantFeedback merchantFeedback) throws CapstoreException {
		authenticateAdmin();
		Long feedbackId = merchantFeedback.getId();
		if (!merchantFeedbackRepo.existsById(feedbackId)) {
			throw new CapstoreException("Could not find the feedback with id "+feedbackId+".");
		}
		MerchantFeedback merchantFeedbackReturned = merchantFeedbackRepo.getOne(feedbackId);

		if (merchantFeedback.getStatus() != null) {
			merchantFeedbackReturned.setStatus(merchantFeedback.getStatus());
		}
		if (merchantFeedback.getStatus() == MerchantFeedbackStatus.FORWARDED && merchantFeedback.getAdminComment() != null) {
			merchantFeedbackReturned.setAdminComment(merchantFeedback.getAdminComment());
		}

		return merchantFeedbackRepo.save(merchantFeedbackReturned);
	}

	@Override
	public List<MerchantFeedback> getMerchantFeedbacks(String statusString) throws CapstoreException {
		authenticateAdmin();
		MerchantFeedbackStatus status;
		try {
			status = MerchantFeedbackStatus.valueOf(statusString.toUpperCase());
		} catch (IllegalArgumentException e) {
			throw new CapstoreException("Not a valid status");
		}
		return merchantFeedbackRepo.findAllByStatus(status);

	}

	@Override
	public Category updateCategory(Category category) throws CapstoreException {
		if (!categoryRepo.existsById(category.getCategoryId())) {
			throw new CapstoreException("Could not find the category.");
		}
		return categoryRepo.save(category);
	}

	
	



}
