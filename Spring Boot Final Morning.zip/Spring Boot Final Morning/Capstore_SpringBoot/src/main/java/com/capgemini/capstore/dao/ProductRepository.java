package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Category;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ThirdPartyMerchant;
//import com.capgemini.capstore.beans.ThirdPartyMerchant;

public interface ProductRepository extends JpaRepository<Product, Long> {

	List<Product> findAllByCategory(Category category);

	List<Product> findAllByMerchant(Merchant merchant);

	@Query("SELECT p.productId, p.productName,p.productDescription,p.productPrice,p.productDiscount,s.available FROM Product p LEFT OUTER JOIN p.stock s where p.productId=?1")
	Product getProductDetailsById(Long productId);

	@Query("FROM Product as p where lower(p.productName) like lower(concat('%', ?1,'%'))")
	List<Product> getAllProductByProductName(String productName);

	List<Product> findAllByThirdPartyMerchant(ThirdPartyMerchant merchant);
}
