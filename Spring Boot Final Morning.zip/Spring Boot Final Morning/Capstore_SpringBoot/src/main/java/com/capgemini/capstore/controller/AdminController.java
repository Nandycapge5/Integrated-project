package com.capgemini.capstore.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.CapstoreResponse;
import com.capgemini.capstore.beans.Category;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ThirdPartyMerchant;
//import com.capgemini.capstore.beans.ThirdPartyMerchant;
import com.capgemini.capstore.exception.CapstoreException;
import com.capgemini.capstore.service.AdminService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;
	/*
	 * Merchant Operations
	 * 
	 */
	@PostMapping(value = "/merchant/add") // Will be removed when integrated to other modules
	public ResponseEntity<CapstoreResponse> addMerchant(@RequestBody Merchant merchant) throws CapstoreException {
		Merchant merchantReturned = adminService.addMerchant(merchant);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	@PutMapping(value = "/merchant") // Will be removed when integrated to other modules
	public ResponseEntity<CapstoreResponse> updateMerchant(@RequestBody Merchant merchant) throws CapstoreException {
		Merchant merchantReturned = adminService.updateMerchant(merchant);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	@GetMapping(value = "/merchant/all")
	public ResponseEntity<CapstoreResponse> viewAllMerchants() throws CapstoreException {
		List<Merchant> merchants = adminService.viewAllMerchants();
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchants);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@DeleteMapping("/merchant/{merchantId}")
	public ResponseEntity<CapstoreResponse> deleteMerchant(@PathVariable Long merchantId) throws CapstoreException {
		boolean deleted = adminService.deleteMerchant(merchantId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deleted);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@GetMapping("/merchant/{merchantId}")
	public ResponseEntity<CapstoreResponse> viewMerchant(@PathVariable Long merchantId) throws CapstoreException {
		Merchant merchant = adminService.viewMerchant(merchantId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchant);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	/*
	 * Third Party Merchant
	 */
	@PostMapping(value = "/merchant/others/add") // Will be removed when integrated to other modules
	public ResponseEntity<CapstoreResponse> addThirdPartyMerchant(@RequestBody ThirdPartyMerchant merchant) throws CapstoreException {
		ThirdPartyMerchant merchantReturned = adminService.addThirdPartyMerchant(merchant);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	@PutMapping(value = "/merchant/others") // Will be removed when integrated to other modules
	public ResponseEntity<CapstoreResponse> updateThirdPartyMerchant(@RequestBody ThirdPartyMerchant merchant) throws CapstoreException {
		ThirdPartyMerchant merchantReturned = adminService.updateThirdPartyMerchant(merchant);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	@GetMapping(value = "/merchant/others/all")
	public ResponseEntity<CapstoreResponse> viewAllThirdPartyMerchant() throws CapstoreException {
		List<ThirdPartyMerchant> merchants = adminService.viewAllThirdPartyMerchant();
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchants);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@DeleteMapping("/merchant/others/{merchantId}")
	public ResponseEntity<CapstoreResponse> deleteThirdPartyMerchant(@PathVariable Long merchantId) throws CapstoreException {
		boolean deleted = adminService.deleteThirdPartyMerchant(merchantId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deleted);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@GetMapping("/merchant/others/{merchantId}")
	public ResponseEntity<CapstoreResponse> GetMerchant(@PathVariable Long merchantId) throws CapstoreException {
		Merchant merchant = adminService.viewMerchant(merchantId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchant);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	
	
/*
 * Merchant feedback
 * 
 */
	@PostMapping(value = "/merchantfeedback/add")
	public ResponseEntity<CapstoreResponse> addFeedbackStatus(@RequestBody MerchantFeedback merchantFeedback) throws CapstoreException {
		MerchantFeedback merchantFeedbackReturned = adminService.addMerchantFeedback(merchantFeedback);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantFeedbackReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	@PutMapping(value = "/merchantfeedback")
	public ResponseEntity<CapstoreResponse> changeFeedbackStatus(@RequestBody MerchantFeedback merchantFeedback) throws CapstoreException {
		MerchantFeedback merchantFeedbackReturned = adminService.changeFeedbackStatus(merchantFeedback);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantFeedbackReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	@GetMapping(value = "/merchantfeedback/{status}") 
	public ResponseEntity<CapstoreResponse> getMerchantFeedbacks(@PathVariable String status) throws CapstoreException {
		List<MerchantFeedback> merchantFeedbacksReturned = adminService.getMerchantFeedbacks(status);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchantFeedbacksReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}
	/*
	 * Product Operations
	 * 
	 */
	@PostMapping(value = "/product/add")
	public ResponseEntity<CapstoreResponse> addProduct(@Valid @RequestBody Product product) throws CapstoreException {
		Product productReturned = adminService.addProduct(product);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, productReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}

	@GetMapping(value = "/product/all")
	public ResponseEntity<CapstoreResponse> viewAllProducts() throws CapstoreException {
		List<Product> products = adminService.viewAllProducts();
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, products);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@GetMapping(value = "/product/{productId}")
	public ResponseEntity<CapstoreResponse> viewProduct(@PathVariable Long productId) throws CapstoreException {
		Product product = adminService.viewProduct(productId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, product);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@DeleteMapping("/product/{productId}")
	public ResponseEntity<CapstoreResponse> deleteProduct(@PathVariable Long productId) throws CapstoreException {
		boolean deleted = adminService.deleteProduct(productId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deleted);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@GetMapping("/merchant/product/{merchantId}")
	public ResponseEntity<CapstoreResponse> findAllProductsByMerchantId(@PathVariable Long merchantId)
			throws CapstoreException {
		List<Product> products = adminService.findAllProductsByMerchantId(merchantId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, products);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@GetMapping("/category/product/{categoryId}")
	public ResponseEntity<CapstoreResponse> findAllProductsByCategoryId(@PathVariable Long categoryId)
			throws CapstoreException {
		List<Product> products = adminService.findAllProductsByCategoryId(categoryId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, products);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@GetMapping("/merchant/others/product/{thirdPartyMerchantId}")
	public ResponseEntity<CapstoreResponse> findAllProductsByThirdPartyMerchantId(@PathVariable Long thirdPartyMerchantId)
			throws CapstoreException {
		List<Product> products = adminService.findAllProductsByThirdPartyMerchantId(thirdPartyMerchantId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, products);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@PutMapping("/stock")
	public ResponseEntity<CapstoreResponse> updateStock(@RequestBody Product product) throws CapstoreException
	{
		Product productReturned = adminService.updateStock(product);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, productReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	/*
	 * Admin Search Operations
	 * 
	 */
	@GetMapping("/product/search/{productName}")
	public ResponseEntity<CapstoreResponse> productSearch(@PathVariable String productName) throws CapstoreException {
		List<Product> products = adminService.getAllProductByProductName(productName);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, products);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@GetMapping("/customer/search/{customerName}")
	public ResponseEntity<CapstoreResponse> customerSearch(@PathVariable String customerName) throws CapstoreException {
		List<Customer> customers = adminService.getAllCustomerByCustomerName(customerName);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, customers);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@GetMapping("/merchant/search/{merchantName}")
	public ResponseEntity<CapstoreResponse> merchantSearch(@PathVariable String merchantName) throws CapstoreException {
		List<Merchant> merchants = adminService.getAllMerchantByMerchantName(merchantName);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, merchants);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	/*
	 * Coupon Operations
	 * 
	 */
	@PostMapping(value = "/coupon/add")
	public ResponseEntity<CapstoreResponse> addCoupon(@RequestBody Coupon coupon) throws CapstoreException {

		Coupon couponReturned = adminService.addCoupon(coupon);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, couponReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@GetMapping(value = "/coupon/all")
	public ResponseEntity<CapstoreResponse> showAllCoupon() throws CapstoreException {
		List<Coupon> coupons = adminService.viewAllCoupons();
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, coupons);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@PutMapping(value = "/coupon")
	public ResponseEntity<CapstoreResponse> updateCoupon(@RequestBody Coupon coupon) throws CapstoreException {
		Coupon couponReturned = adminService.updateCoupon(coupon);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, couponReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}

	@DeleteMapping("/coupon/{couponId}")
	public ResponseEntity<CapstoreResponse> deleteCoupon(@PathVariable Long couponId) throws CapstoreException {
		boolean deleted = adminService.deleteCoupon(couponId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deleted);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	
	/*
	 * Delivery Status
	 * 
	 */
	@PostMapping("/deliverystatus")//adding dummy data
	public ResponseEntity<CapstoreResponse> addDeliveryStatus(@RequestBody DeliveryStatus deliveryStatus) throws CapstoreException {
		DeliveryStatus deliveryStatusReturned = adminService.addDeliveryStatus(deliveryStatus);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deliveryStatusReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@GetMapping("/deliverystatus/{statusString}")
	public ResponseEntity<CapstoreResponse> getDeliveryStatus(@PathVariable String statusString) throws CapstoreException {
		List<DeliveryStatus> deliveryData = adminService.getDeliveryStatus(statusString);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deliveryData);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@PutMapping("/deliverystatus/{deliveryStatusId}/{statusString}")
	public ResponseEntity<CapstoreResponse> updateDeliveryStatus(@PathVariable Long deliveryStatusId,@PathVariable String statusString) throws CapstoreException {
		DeliveryStatus deliveryData = adminService.updateDeliveryStatus(deliveryStatusId, statusString);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deliveryData);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	/*
	 * Category Methods
	 * 
	 */
	@PostMapping(value = "/category/add")
	public ResponseEntity<CapstoreResponse> addProduct(@RequestBody Category category) throws CapstoreException {
		Category categoryReturned = adminService.addCategory(category);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, categoryReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.CREATED);
		return response;
	}

	@GetMapping(value = "/category/all")
	public ResponseEntity<CapstoreResponse> viewAllCategory() throws CapstoreException {
		List<Category> categories = adminService.viewAllCategory();
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, categories);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@GetMapping("/category/{categoryId}")
	public ResponseEntity<CapstoreResponse> getCategory(@PathVariable Long categoryId) throws CapstoreException {
		Category category = adminService.getCategory(categoryId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, category);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@DeleteMapping("/category/{categoryId}")
	public ResponseEntity<CapstoreResponse> deleteCategory(@PathVariable Long categoryId) throws CapstoreException {
		boolean deleted = adminService.deleteCategory(categoryId);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, deleted);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@PutMapping("/category")
	public ResponseEntity<CapstoreResponse> updateCategory(@RequestBody Category category) throws CapstoreException {
		Category categoryReturned = adminService.updateCategory(category);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, categoryReturned);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	
	/*
	 * Cart Management
	 */
	@PutMapping("/cart/{value}")
	public ResponseEntity<CapstoreResponse> changeCartMinimumValue(@PathVariable Double value) throws CapstoreException {
		String returnedData = adminService.changeCartMinimumValue(value);
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, returnedData);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
	@GetMapping("/cart")
	public ResponseEntity<CapstoreResponse> getCartMinimumValue() {
		Double returnedData = adminService.getCartMinimumValue();
		CapstoreResponse capstoreResponse = new CapstoreResponse(true, returnedData);
		ResponseEntity<CapstoreResponse> response = new ResponseEntity<CapstoreResponse>(capstoreResponse,
				HttpStatus.OK);
		return response;
	}
}
