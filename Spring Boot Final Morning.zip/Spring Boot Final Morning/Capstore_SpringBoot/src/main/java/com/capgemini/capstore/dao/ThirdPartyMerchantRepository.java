package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.ThirdPartyMerchant;

public interface ThirdPartyMerchantRepository extends JpaRepository<ThirdPartyMerchant, Long> {

}
