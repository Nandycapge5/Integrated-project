package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Category;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ThirdPartyMerchant;
//import com.capgemini.capstore.beans.ThirdPartyMerchant;
import com.capgemini.capstore.exception.CapstoreException;

public interface AdminService {

	/*
	 * Merchant Operations
	 */
	Merchant addMerchant(Merchant merchant) throws CapstoreException;

	boolean deleteMerchant(Long merchantId) throws CapstoreException;

	List<Merchant> viewAllMerchants() throws CapstoreException;

	Merchant updateMerchant(Merchant merchant) throws CapstoreException;

	Merchant viewMerchant(Long merchantId) throws CapstoreException;

	/*
	 * Coupon Operations
	 * 
	 */

	Coupon addCoupon(Coupon coupon) throws CapstoreException;

	Coupon updateCoupon(Coupon coupon) throws CapstoreException;

	boolean deleteCoupon(Long couponId) throws CapstoreException;

	List<Coupon> viewAllCoupons() throws CapstoreException;

	/*
	 * Category Operations
	 * 
	 */
	boolean deleteCategory(Long categoryId) throws CapstoreException;

	Category addCategory(Category category) throws CapstoreException;

	Category getCategory(Long categoryId) throws CapstoreException;

	List<Category> viewAllCategory() throws CapstoreException;

	Category updateCategory(Category category) throws CapstoreException;

	/*
	 * Product Operations
	 */
	Product addProduct(Product product) throws CapstoreException;

	List<Product> viewAllProducts() throws CapstoreException;

	Product viewProduct(Long productId) throws CapstoreException;

	boolean deleteProduct(Long productId) throws CapstoreException;

	List<Product> findAllProductsByMerchantId(Long merchantId) throws CapstoreException;

	List<Product> findAllProductsByCategoryId(Long categoryId) throws CapstoreException;

	List<Product> getAllProductByProductName(String productName) throws CapstoreException;

	List<Customer> getAllCustomerByCustomerName(String CustomerName) throws CapstoreException;

	List<Merchant> getAllMerchantByMerchantName(String merchantName) throws CapstoreException;

	Product updateStock(Product product) throws CapstoreException;
	/*
	 * List<DeliveryStatus> getDeliveryStatus(String statusString) throws
	 * CapstoreException;
	 * 
	 * DeliveryStatus updateDeliveryStatus(Long deliveryStatusId, String
	 * statusString) throws CapstoreException;
	 */
	/*
	 * Third Party Merchant Operations
	 */

	ThirdPartyMerchant viewThirdPartyMerchant(Long merchantId) throws CapstoreException;

	List<ThirdPartyMerchant> viewAllThirdPartyMerchant() throws CapstoreException;

	boolean deleteThirdPartyMerchant(Long merchantId) throws CapstoreException;

	ThirdPartyMerchant addThirdPartyMerchant(ThirdPartyMerchant merchant) throws CapstoreException;

	List<Product> findAllProductsByThirdPartyMerchantId(Long merchantId) throws CapstoreException;

	ThirdPartyMerchant updateThirdPartyMerchant(ThirdPartyMerchant merchant) throws CapstoreException;

	/*
	 * Cart Management
	 */
	String changeCartMinimumValue(double value) throws CapstoreException;
	Double getCartMinimumValue();

	void authenticateAdmin() throws CapstoreException;

	MerchantFeedback changeFeedbackStatus(MerchantFeedback merchantFeedback) throws CapstoreException;

	MerchantFeedback addMerchantFeedback(MerchantFeedback merchantFeedback);

	List<MerchantFeedback> getMerchantFeedbacks(String status) throws CapstoreException;

	DeliveryStatus updateDeliveryStatus(Long deliveryStatusId, String statusString) throws CapstoreException;

	List<DeliveryStatus> getDeliveryStatus(String statusString) throws CapstoreException;

	DeliveryStatus addDeliveryStatus(DeliveryStatus deliveryStatus);



}
