package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name = "capstore_stock")
public class Stock {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stock_seq_gen")
	@SequenceGenerator(name = "stock_seq_gen", initialValue = 10000, sequenceName = "stock_seq")
	private long stockId;
	@Min(1)
	@Max(100)
	private int available;
	@Min(1)
	@Max(10000)
	private int totalQuantity;

	public Stock() {	
		super();
	}

	public Stock(int available, int totalQuantity) {
		super();
		this.available = available;
		this.totalQuantity = totalQuantity;
	}

	public int getAvailable() {
		return available;
	}

	public void setAvailable(int available) {
		this.available = available;
	}

	public int getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}


}
