import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menfootwear',
  templateUrl: './menfootwear.component.html',
  styleUrls: ['./menfootwear.component.css']
})
export class MenfootwearComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
