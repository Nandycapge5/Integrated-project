import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KidsaccessoriesComponent } from './kidsaccessories.component';

describe('KidsaccessoriesComponent', () => {
  let component: KidsaccessoriesComponent;
  let fixture: ComponentFixture<KidsaccessoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KidsaccessoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KidsaccessoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
