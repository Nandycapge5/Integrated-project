import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kidsaccessories',
  templateUrl: './kidsaccessories.component.html',
  styleUrls: ['./kidsaccessories.component.css']
})
export class KidsaccessoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
