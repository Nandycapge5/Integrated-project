import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menwatches',
  templateUrl: './menwatches.component.html',
  styleUrls: ['./menwatches.component.css']
})
export class MenwatchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
