import { NgModule, Component } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import {MenComponent} from 'src/app/men/men.component';
import {WomenComponent} from 'src/app/women/women.component';
import {KidsComponent} from 'src/app/kids/kids.component';
import{MenclothesComponent} from 'src/app/menclothes/menclothes.component';
import{MenaccessoriesComponent} from 'src/app/menaccessories/menaccessories.component';
import{MenfootwearComponent} from 'src/app/menfootwear/menfootwear.component';
import{MenwatchesComponent} from 'src/app/menwatches/menwatches.component';
import{KidsclothesComponent} from 'src/app/kidsclothes/kidsclothes.component';
import{KidsfootwearComponent} from 'src/app/kidsfootwear/kidsfootwear.component';
import{KidstoysComponent} from 'src/app/kidstoys/kidstoys.component';
import{KidsaccessoriesComponent} from 'src/app/kidsaccessories/kidsaccessories.component';
import{WomenaccessoriesComponent} from 'src/app/womenaccessories/womenaccessories.component';
import{WomenclothingComponent} from 'src/app/womenclothing/womenclothing.component';
import{WomenfootwearComponent} from 'src/app/womenfootwear/womenfootwear.component';
import{WomenwatchesComponent} from 'src/app/womenwatches/womenwatches.component';
import{ViewdescriptionComponent} from 'src/app/viewdescription/viewdescription.component';


const routes: Routes = [
  {
    path:'app-men',
    component:MenComponent
  },
  {
    path:'app-women',
    component:WomenComponent
  },
  {
    path:'app-kids',
    component:KidsComponent
  },
  
  {
    path:'app-menfootwear',
    component:MenfootwearComponent
  },
  {
    path:'app-menwatches',
    component:MenwatchesComponent
  },
  {
    path:'app-menaccessories',
    component:MenaccessoriesComponent
  },
  {
    path:'app-menclothes',
    component:MenclothesComponent
  },
  {
    path:'app-kidsclothes',
    component:KidsclothesComponent
  },
  {
    path:'app-kidstoys',
    component:KidstoysComponent
  },
  {
    path:'app-kidsfootwear',
    component:KidsfootwearComponent
  },
  {
    path:'app-kidsaccessories',
    component:KidsaccessoriesComponent
  },
  {
    path:'app-womenclothing',
    component:WomenclothingComponent
  },
  {
    path:'app-viewdescription',
    component:ViewdescriptionComponent
  },
  {
    path:'app-womenfootwear',
    component:WomenfootwearComponent
  },
  {
    path:'app-womenwatches',
    component:WomenwatchesComponent
  },
  {
    path:'app-womenwatches',
    component:WomenwatchesComponent
  },
  {
    path:'app-womenaccessories',
    component:WomenaccessoriesComponent
  }

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
