import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womenfootwear',
  templateUrl: './womenfootwear.component.html',
  styleUrls: ['./womenfootwear.component.css']
})
export class WomenfootwearComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
