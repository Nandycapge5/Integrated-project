import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womenaccessories',
  templateUrl: './womenaccessories.component.html',
  styleUrls: ['./womenaccessories.component.css']
})
export class WomenaccessoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
