package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.capgemini.capstore.beans.Customer;

@Repository
@CrossOrigin(origins="http://localhost:4200")
public interface CustomerDao extends JpaRepository<Customer, Long> {

}
