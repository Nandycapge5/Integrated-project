import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MerchantServiceService } from 'src/app/services/merchant-service.service';
import { Category } from 'src/app/Models/Category';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  enableMe:boolean=false;
  addProductForm: FormGroup;
  submitted = false;
  categoryArr: Category[] = [];
  default: string ; 

  constructor(private formBuilder: FormBuilder,private merchantService:MerchantServiceService,private router:Router) {
    this.merchantService = merchantService; 
    this.formBuilder = formBuilder;
    this.router = router;
  }

  fetchCategories(){
    let obj = this.merchantService.getCategories();
    obj
      .subscribe((data) => {
        for(let a of data){
          let obj = new Category(a.categoryId,a.categoryGender,a.categoryType);
          this.categoryArr.push(obj);
          this.default = this.categoryArr[0].categoryType;
        }
       
      })
  }

  ngOnInit() {

    this.fetchCategories();

    this.addProductForm = this.formBuilder.group({
      productName : ['', [Validators.required,Validators.pattern('[a-zA-Z][a-zA-Z ]+')]],
      productDescription :  ['', [Validators.required]],
      productPrice: ['',[Validators.required,Validators.pattern('[+]?\\d*\\.?\\d+'),Validators.minLength(1),Validators.maxLength(5)]],
      productDiscount: ['',[Validators.required,Validators.pattern('[+]?\\d*\\.?\\d+'),Validators.maxLength(2)]],
      categories : ['', [Validators.required]],
      productQuantity : ['',[Validators.required,,Validators.pattern('^(0|[1-9][0-9]*)$'),Validators.maxLength(2)]]
    })
    this.addProductForm.controls['categories'].setValue(this.default, {onlySelf: true});
    
   
  }

  get f() { return this.addProductForm.controls; }

  onSubmit(){
    this.submitted = true;
    if(this.addProductForm.invalid){
      return;
    }
    let productName = this.addProductForm.get('productName').value;
    let productDescription = this.addProductForm.get('productDescription').value;
    let productPrice = this.addProductForm.get('productPrice').value;
    let productDiscount = this.addProductForm.get('productDiscount').value;
    let productQuantity = this.addProductForm.get('productQuantity').value;
    let category = this.addProductForm.get('categories').value;
    
    let obj = this.merchantService.addProduct(productName, productDescription, productPrice, productDiscount, productQuantity, category.categoryId);
    obj.
        subscribe((data)=>{
          alert("Product Added Successfully.");
          this.router.navigate(['merchant']);
        })
  }

}
