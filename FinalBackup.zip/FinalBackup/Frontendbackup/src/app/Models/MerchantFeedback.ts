import { Customer } from './Customer';

export class MerchantFeedback {
    id:number;
    customer: Customer;
    merchantFeedback: string;
    response: string;
    adminComment: String;
    status:String;
    
    constructor(id:number,customer: Customer,merchantFeedback: string,adminComment: String,status:String) {
    this.id = id;
    this.customer=customer;
    this.merchantFeedback=merchantFeedback;
    this.adminComment = adminComment;
    this.status = status;
    }
}