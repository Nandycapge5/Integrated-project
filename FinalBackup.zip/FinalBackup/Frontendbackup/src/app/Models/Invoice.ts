export class Invoice{
    invoiceId:number;
    adminDiscount:number;
    finalAmount:number;
    customerId:number;

    constructor(invoiceId:number,adminDiscount:number,finalAmount:number,customerId:number){
        this.invoiceId = invoiceId;
        this.adminDiscount = adminDiscount;
        this.finalAmount = finalAmount;
        this.customerId = customerId;
    }

}
