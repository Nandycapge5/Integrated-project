import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { Stock } from '../Models/Stock';
import { Product } from '../Models/Product';
import { MerchantFeedback } from '../Models/MerchantFeedback';
import { Merchant } from '../Models/Merchant';
import { Category } from '../Models/Category';
import { Order } from '../Models/Order';

@Injectable({
  providedIn: 'root'
})
export class MerchantServiceService {

  http: HttpClient

  constructor(http: HttpClient) {
    this.http = http;
  }
  static merchantId: number

  handleError(error) {
    console.log(error)
    let errorMessage = error['error']['message'];
    // if(errorMessage!=null)
    // {
    window.alert(errorMessage);
    // }
    // else{
    //   window.alert("");
    // }
    return throwError(errorMessage);
  }

  getAllMerchantsProduct(merchantId: number): Observable<Stock[]> {
    let url = "http://localhost:1001/merchant/product/getProductsByMerchantId/10050";
    return this.http.get<Stock[]>(url).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  deleteProductById(productId: number): Observable<boolean> {
    let url = "http://localhost:1001/merchant/product/deleteProduct/productId/" + productId;
    return this.http.delete<boolean>(url).pipe(
      retry(1),
      catchError(this.handleError));
  }

  addQuantity(productId: number, quantity: number): Observable<Product> {
    let url = "http://localhost:1001/merchant/product/addProductQuantity/" + productId + "/" + quantity;
    return this.http.put<Product>(url, null).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  deleteQuantity(productId: number, quantity: number): Observable<Product> {
    let url = "http://localhost:1001/merchant/product/deleteProductQuantity/" + productId + "/" + quantity;
    return this.http.put<Product>(url, null).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  updateDiscount(productId: number, discount: number): Observable<Product> {
    let url = "http://localhost:1001/merchant/product/addDiscount";
    let jsonObj = {
      "productId": productId,
      "productDiscount": discount
    }
    return this.http.put<Product>(url, jsonObj).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  fetchMerchantFeedback(): Observable<MerchantFeedback[]> {
    let url = "http://localhost:1001/merchant/product/getMerchantFeedback/10000";
    return this.http.get<MerchantFeedback[]>(url).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  sendFeedbackResponse(id: number, response: string): Observable<MerchantFeedback> {
    let url = "http://localhost:1001/merchant/product/sendMerchantFeedback";
    let jsonObj = {
      "id": id,
      "response": response,
      "status": "2"
    }
    return this.http.put<MerchantFeedback>(url, jsonObj).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  searchMerchantProducts(userInput: string): Observable<Stock[]> {


    let url = "http://localhost:1001/merchant/product/searchProducts/10050/" + userInput;
    return this.http.get<Stock[]>(url).pipe(
      retry(1),
      catchError(this.handleError)
    );


  }

  getMerchantProfile(): Observable<Merchant> {
    let url = "http://localhost:1001/merchant/getMerchantProfile/10050";
    return this.http.get<Merchant>(url).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  getCategories(): Observable<Category[]> {
    let url = "http://localhost:1001/merchant/product/categories";
    return this.http.get<Category[]>(url).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  addProduct(productName: string, productDescription: string, productPrice: number, productDiscount: number, productQuantity: number, categoryId: number): Observable<Product> {
    let url = "http://localhost:1001/merchant/product/add/" + productQuantity;
    let jsonObj = {
      "productName": productName,
      "productDescription": productDescription,
      "productPrice": productPrice,
      "productDiscount": productDiscount,
      "merchant": {
        "merchantId": "10050"
      },
      "category": {
        "categoryId": categoryId
      }
    }

    return this.http.post<Product>(url, jsonObj).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  getAllOrders(): Observable<Order[]> {
    let url = "http://localhost:1001/merchant/order/getAllOrders/10050";
    return this.http.get<Order[]>(url).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

}
