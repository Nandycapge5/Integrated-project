package com.capgemini.capstore.exceptions;

@SuppressWarnings("serial")
public class UnauthorizedException extends RuntimeException{

	public UnauthorizedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnauthorizedException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
}
