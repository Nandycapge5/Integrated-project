import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/entity/Merchant';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {


  merchants: Merchant[] = [];
  service: AdminServiceService;

  constructor(private router:Router,service: AdminServiceService) {
    this.service = service;
    this.getAllMerchants();
    console.log(this.merchants)
  }
  ngOnInit() {
    
  }
  getAllMerchants() {
    this.service.getAllMerchants().then(response => {
      this.merchants = response.result;
      console.log(response.result);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  deleteMerchant(merchantId) {
    this.service.deleteMerchant(merchantId).then(response => {
      if(response.success == true)
      {
        alert("Merchant removed successfully");
        this.getAllMerchants();
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
