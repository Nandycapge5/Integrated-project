import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllPackedProductsComponent } from './all-packed-products.component';

describe('AllPackedProductsComponent', () => {
  let component: AllPackedProductsComponent;
  let fixture: ComponentFixture<AllPackedProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllPackedProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllPackedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
