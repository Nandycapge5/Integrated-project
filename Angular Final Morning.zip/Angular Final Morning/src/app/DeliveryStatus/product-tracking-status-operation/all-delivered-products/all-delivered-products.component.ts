import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from 'src/app/Entity/Data';

@Component({
  selector: 'app-all-delivered-products',
  templateUrl: './all-delivered-products.component.html',
  styleUrls: ['./all-delivered-products.component.css']
})
export class AllDeliveredProductsComponent implements OnInit {

  service:AdminServiceService;
  constructor(service:AdminServiceService) { this.service=service}
  response: any;
  ngOnInit() {
    this.fetchDeliveryStatus();

  }
  fetchDeliveryStatus() {
    this.service.fetchDeliveryStatus('delivered').then(response => {
    this.response = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
