import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from 'src/app/Entity/Data';

@Component({
  selector: 'app-all-cancelled-products',
  templateUrl: './all-cancelled-products.component.html',
  styleUrls: ['./all-cancelled-products.component.css']
})
export class AllCancelledProductsComponent implements OnInit {

  service:AdminServiceService;
  constructor(service:AdminServiceService) { this.service=service}
  response: any;
  ngOnInit() {
    this.fetchDeliveryStatus();

  }
  fetchDeliveryStatus() {
    this.service.fetchDeliveryStatus('cancelled').then(response => {
    this.response = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
