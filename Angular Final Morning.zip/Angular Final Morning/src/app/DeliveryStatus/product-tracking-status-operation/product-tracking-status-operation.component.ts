import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-tracking-status-operation',
  templateUrl: './product-tracking-status-operation.component.html',
  styleUrls: ['./product-tracking-status-operation.component.css']
})
export class ProductTrackingStatusOperationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
