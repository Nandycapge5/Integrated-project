import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/Entity/Coupon';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-show-coupon',
  templateUrl: './show-coupon.component.html',
  styleUrls: ['./show-coupon.component.css']
})
export class ShowCouponComponent implements OnInit {

  coupons: Coupon[] = [];
  service: AdminServiceService;
  constructor(service: AdminServiceService) {
    this.service = service;
    this.getAllCoupons();
    console.log(this.coupons);
  }
  ngOnInit() {

  }
  getAllCoupons() {
    this.service.getAllCoupons().then(response => {
      this.coupons = response.result;
      console.log(response.result);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      
      });
  }
  deleteCoupon(couponId: number) {
    this.service.deleteCoupon(couponId).then(response => {
      if (response.result == true) {
        alert("Coupon Removed successfully");
        this.getAllCoupons();
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }

}
