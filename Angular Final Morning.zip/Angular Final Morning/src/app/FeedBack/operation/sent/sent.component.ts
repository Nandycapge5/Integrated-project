import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.css']
})
export class SentComponent implements OnInit {
  merchantFeedbacks: any;
  constructor(private service: AdminServiceService) { }

  ngOnInit() {
    this.getMerchantFeedbacks();
  }
  getMerchantFeedbacks() {
    this.service.getMerchantFeedbacks('SENT_TO_CUSTOMER').then(response => {
      this.merchantFeedbacks = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
