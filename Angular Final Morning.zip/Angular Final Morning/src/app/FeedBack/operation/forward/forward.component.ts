import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-forward',
  templateUrl: './forward.component.html',
  styleUrls: ['./forward.component.css']
})
export class ForwardComponent implements OnInit {
  merchantFeedbacks: any;
  constructor(private service: AdminServiceService) { }

  ngOnInit() {
    this.getMerchantFeedbacks();
  }
  getMerchantFeedbacks() {
    this.service.getMerchantFeedbacks('forwarded').then(response => {
      this.merchantFeedbacks = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
