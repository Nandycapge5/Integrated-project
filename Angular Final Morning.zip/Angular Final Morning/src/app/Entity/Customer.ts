export class Customer{
    customerId:number;
    customerAddress:string;
    customerAnswer:string;
    customerContactNo:string;
    customerName:string;
    customerPassword:string;
    customerQuestion:number;
    customerStatus:number
    
        constructor( customerId:number,customerAddress:string,customerAnswer:string,customerContactNo:string,customerName:string,customerPassword:string,customerQuestion:number,customerStatus:number)
        {
          this.customerId=customerId;
          this.customerAddress=customerAddress;
          this.customerAnswer=customerAnswer;
          this.customerContactNo=customerContactNo;
          this.customerName=customerName;
          this.customerPassword=customerPassword;
          this.customerQuestion=customerQuestion;
          this.customerStatus=customerStatus;
        }
    }