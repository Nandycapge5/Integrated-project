import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Entity/Category';
import { AdminServiceService } from 'src/app/Service/admin-service.service';



@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {
  service: AdminServiceService;
  constructor(service: AdminServiceService) {
    this.service = service;
  }

  ngOnInit() {
  }
  addCategory(data: any) {
    let createdCategory:Category = new Category(0, data.categoryGender, data.categoryType);
    this.service.addCategory(createdCategory).then(response => {
      if (response.success == true) {
        alert("Category added.")
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
