import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  service: AdminServiceService;
  merchantId: any;
  products: Product[] = [];
  constructor(service: AdminServiceService) {
    this.service = service;
    this.getAllProducts();
  }
  ngOnInit() {

  }

  getAllProducts() {
    this.service.getAllProducts().then(response => {
      this.products = response.result;
      console.log(response.result);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }

  deleteProduct(productId: number) {
    this.service.deleteProduct(productId).then(response => {
      if (response.result == true) {
        alert("Product Deleted Successfully");
      }
        this.getAllProducts();
      
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });

  }
}
